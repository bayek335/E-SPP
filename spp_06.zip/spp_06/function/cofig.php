<?php
//di baris kedua setelah pembuka php

// konfigurasi database
define('hostname', '127.0.0.1');
define('username', 'root');
define('password', '');
define('database', 'db_spp');

//konfigurasi url
define('url', '/native/spp_06/public/');

//author
define('author', 'BayuPamungkas');
