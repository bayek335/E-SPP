<?php

//File untuk menyimpan semua class dan file tertentu 
//yang dibutuhkan pada tampilan

session_start();
require 'cofig.php';
require 'koneksi.php';
require 'Auth.php';
require 'Petugas.php';
require 'Spp.php';
require 'Kelas.php';
require 'Siswa.php';
require 'Pembayaran.php';
require 'Tanggungan.php';
