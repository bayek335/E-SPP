<footer>
    <p>&copy CopyRight <?= author . " " . date('Y') ?></p>
</footer>
<script src="<?= url ?>assets/custom.js.js"></script>
</body>

</html>